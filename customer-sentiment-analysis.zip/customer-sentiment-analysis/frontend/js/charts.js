/* Chart.js helpers */

let doughnutChart = null;
let trendChart = null;

const SENTIMENT_COLORS = {
  Positive: '#059669',
  Negative: '#dc2626',
  Neutral: '#d97706',
};

function destroyChart(chart) {
  if (chart) {
    chart.destroy();
  }
  return null;
}

function renderDoughnut(stats) {
  const canvas = document.getElementById('doughnutChart');
  const empty = document.getElementById('doughnutEmpty');
  if (!canvas) return;

  const pos = stats.positive_count || 0;
  const neg = stats.negative_count || 0;
  const neu = stats.neutral_count || 0;
  const total = pos + neg + neu;

  doughnutChart = destroyChart(doughnutChart);

  if (total === 0) {
    empty.classList.remove('hidden');
    return;
  }
  empty.classList.add('hidden');

  doughnutChart = new Chart(canvas, {
    type: 'doughnut',
    data: {
      labels: ['Positive', 'Negative', 'Neutral'],
      datasets: [{
        data: [pos, neg, neu],
        backgroundColor: [SENTIMENT_COLORS.Positive, SENTIMENT_COLORS.Negative, SENTIMENT_COLORS.Neutral],
        borderWidth: 0,
        hoverOffset: 6,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: { usePointStyle: true, padding: 16, font: { size: 12 } },
        },
      },
      cutout: '62%',
    },
  });
}

function renderTrend(trends) {
  const canvas = document.getElementById('trendChart');
  const empty = document.getElementById('trendEmpty');
  if (!canvas) return;

  trendChart = destroyChart(trendChart);

  if (!trends || trends.length === 0) {
    empty.classList.remove('hidden');
    return;
  }
  empty.classList.add('hidden');

  const labels = trends.map(t => t.date);
  const pos = trends.map(t => t.Positive || 0);
  const neg = trends.map(t => t.Negative || 0);
  const neu = trends.map(t => t.Neutral || 0);

  trendChart = new Chart(canvas, {
    type: 'line',
    data: {
      labels,
      datasets: [
        {
          label: 'Positive',
          data: pos,
          borderColor: SENTIMENT_COLORS.Positive,
          backgroundColor: 'rgba(5,150,105,0.1)',
          fill: true,
          tension: 0.3,
          pointRadius: 3,
        },
        {
          label: 'Negative',
          data: neg,
          borderColor: SENTIMENT_COLORS.Negative,
          backgroundColor: 'rgba(220,38,38,0.08)',
          fill: true,
          tension: 0.3,
          pointRadius: 3,
        },
        {
          label: 'Neutral',
          data: neu,
          borderColor: SENTIMENT_COLORS.Neutral,
          backgroundColor: 'rgba(217,119,6,0.08)',
          fill: true,
          tension: 0.3,
          pointRadius: 3,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: {
          position: 'bottom',
          labels: { usePointStyle: true, padding: 16, font: { size: 12 } },
        },
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: { font: { size: 11 }, maxRotation: 45 },
        },
        y: {
          beginAtZero: true,
          ticks: { precision: 0, font: { size: 11 } },
          grid: { color: 'rgba(0,0,0,0.04)' },
        },
      },
    },
  });
}
